@extends('layouts.main')

@section('content')
    <div style="width:100%;height:20px;">
    </div>
    <center>
        <h3>TATA TERTIB</h3>
    </center>
    <div style="width:100%;height:200px;">
    </div>
@endsection
