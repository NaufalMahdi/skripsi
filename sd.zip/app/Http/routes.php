<?php


Route::get('viewAlldownloadfile','DownloadController@downfunc');