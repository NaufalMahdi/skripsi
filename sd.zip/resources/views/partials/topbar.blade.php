<!-- ======= Top Bar ======= -->
<section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
            <i class=""></i><a href="">Jl.Dewi Sartika No.17, Kampungtengah, Kepatihan, Kec. Kaliwates,
                Kabupaten Jember, Jawa Timur </a>
            <i class="bi bi-phone-fill phone-icon"></i> (0331) 486988
        </div>
        <div class="social-links d-none d-md-block">
            <a href="https://www.youtube.com/@exhibitionofsmpn01jember91" class="youtube"><i class="bi bi-youtube"></i></a>
            <a href="https://www.facebook.com/SMPN-1-Jember-455192411224571" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/osismpkspasa" class="instagram"><i class="bi bi-instagram"></i></a>
        </div>
    </div>
</section>
