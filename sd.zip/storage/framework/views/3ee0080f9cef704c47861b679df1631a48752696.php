<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">   
    <a class="navbar-brand" href="/">Welcome</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title === "Home") ? 'active' : ''); ?>" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title === "About") ? 'active' : ''); ?>" href="/about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title === "Posts") ? 'active' : ''); ?>" href="/posts">Blog</a>
        </li>
      </ul>

      <ul class="navbar-nav ms-auto">
        <?php if(auth()->guard()->check()): ?>
<div class="btn-group">
  <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Welcome back, <?php echo e(auth()->user()->name); ?>

  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="/dashboard"><i> Dashboard</i>
    <div class="dropdown-divider"></div>

    <form action="/logout" method="post">
      <?php echo csrf_field(); ?>
      <button type="submit" class="dropdown-item">Logout</button>
    </form>
    <!-- <a class="dropdown-item" href="#">Logout</a> -->
  </div>
</div>

        <?php else: ?>
        <li class="nav-item">
          <a href="/login" class="nav-link <?php echo e(($title === "Login") ? 'active' : ''); ?>"><i class="bi bi-box-arrow-in-right"></i>
          Login</a>
        </li>
        <?php endif; ?>
      </ul>

    </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\projek_pkl2\resources\views/partials/navbar.blade.php ENDPATH**/ ?>