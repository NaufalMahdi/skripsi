

<?php $__env->startSection('container'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
		<h2><?php echo e($post->title); ?></h2>


		<p>Kategori : <a href="/kategories"><?php echo e($post->kategori->name); ?> </a></p>

			<img src="https://source.unsplash.com/1200x400?<?php echo e($post->kategori->name); ?>" class="card-img-top" alt="<?php echo e($post->kategori->name); ?>" class="img-fluid">
			
			<?php echo $post->body; ?>

			<a href="/posts">Back to Posts</a>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek_pkl2\resources\views/post.blade.php ENDPATH**/ ?>