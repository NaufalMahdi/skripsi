
 

 <?php $__env->startSection('container'); ?>

 <h1 class="mb-5">Kumpulan Data Pada Kabupaten Lumajang</h1>

<?php if($posts->count()): ?>

 <div class="card mb-3">
  <img src="https://source.unsplash.com/1200x400?<?php echo e($posts[0]->kategori->name); ?>" class="card-img-top" alt="<?php echo e($posts[0]->kategori->name); ?>">
  <div class="card-body text-center">
    <h3 class="card-title"><a href="/posts/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none text-dark"><?php echo e($posts[0]->title); ?></a></h3>
    <p>
    <small class="text-muted">
      Kategori : <a href="/kategories/<?php echo e($posts[0]->kategori->slug); ?> "><?php echo e($posts[0]->kategori->name); ?> </a>
    </small>
   </p>
    <p class="card-text"><?php echo e($posts[0]->excerpt); ?></p>
    <a href="/posts/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none btn btn-primary">Baca Selanjutnya</a>
    <p class="card-text"><small class="text-muted"><?php echo e($posts[0]->created_at->diffForHumans()); ?></small></p>
 
   </div>
</div>
<?php else: ?>
   <p class="text-center fs-4"> No post found.</p>
<?php endif; ?>

<div class="container">
   <div class="row">
   <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="col-md-4 mb-3">
      <div class="card">
      <div class="position-absolute px-3 py-2 text-white" style="background-color: rgba(0, 0, 0, 0.7)"><?php echo e($post->kategori->name); ?></div>
      <img src="https://source.unsplash.com/500x400?<?php echo e($post->kategori->name); ?>" class="card-img-top" alt="<?php echo e($post->kategori->name); ?>">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($post->title); ?></h5>
    <p>
    <small class="text-muted">
      Kategori : <a href="/kategories/<?php echo e($posts[0]->kategori->slug); ?> "><?php echo e($post->kategori->name); ?> </a>
    </small>
   </p>
    <p class="card-text"><?php echo e($post->excerpt); ?></p>
    <a href="/posts/<?php echo e($post->slug); ?>" class="btn btn-primary">Baca Selengkapnya</a>
    <p class="card-text"><small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small></p>
   </div>
</div>  
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
    

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek_pkl2\resources\views/posts.blade.php ENDPATH**/ ?>