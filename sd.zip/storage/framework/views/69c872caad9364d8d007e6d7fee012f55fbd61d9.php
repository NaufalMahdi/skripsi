

<?php $__env->startSection('container'); ?>

<h2><?php echo e($post->title); ?></h2>

<p>Kategori : <a href="/kategories"><?php echo e($post->kategori->name); ?> </a></p>

<?php echo $post->body; ?>



<a href="/posts">Back to Posts</a>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AAAFILE\AAKULIAH\PKL\project\project\project_pkl2\resources\views/post.blade.php ENDPATH**/ ?>